# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
import json
import re
import sys
from pathlib import Path
from typing import Optional
from dataclasses import dataclass
import torch
from einops import rearrange

import numpy as np

# from ladder.schedule.ladder_intrin import (
#     B_global_16x32_to_shared_load_16x32_layout,
# )


transformer_configs = {
    "3B": dict(n_layer=26, n_head=32, dim=3200, vocab_size=100287, n_local_heads=8, intermediate_size=10240),
}

def B_global_16x32_to_shared_load_16x32_layout(i, j):
    """
         stride * 8 * (tx // HALF_WARP_expr)
                + (tx % 8) * stride
                + 16 * ((tx % HALF_WARP_expr) // 8)
    """
    thread_id = i * 2 + j // 16
    row = (thread_id // 16) * 8 + (thread_id % 8)
    col = (j % 16) + 16 * ((thread_id % 16) // 8)
    return row, col

def permutate_weight(weight):
    wmma_n = 16
    wmma_k = 32
    N = weight.shape[0]
    K = weight.shape[1]
# [(0, 0), (0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7), (0, 8), (0, 9), (0, 10), (0, 11), (0, 12), (0, 13), (0, 14), (0, 15), (1, 0), (1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10), (1, 11), (1, 12), (1, 13), (1, 14), (1, 15)]
# [(2, 0), (2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 6), (2, 7), (2, 8), (2, 9), (2, 10), (2, 11), (2, 12), (2, 13), (2, 14), (2, 15), (3, 0), (3, 1), (3, 2), (3, 3), (3, 4), (3, 5), (3, 6), (3, 7), (3, 8), (3, 9), (3, 10), (3, 11), (3, 12), (3, 13), (3, 14), (3, 15)]
# [(4, 0), (4, 1), (4, 2), (4, 3), (4, 4), (4, 5), (4, 6), (4, 7), (4, 8), (4, 9), (4, 10), (4, 11), (4, 12), (4, 13), (4, 14), (4, 15), (5, 0), (5, 1), (5, 2), (5, 3), (5, 4), (5, 5), (5, 6), (5, 7), (5, 8), (5, 9), (5, 10), (5, 11), (5, 12), (5, 13), (5, 14), (5, 15)]
# [(6, 0), (6, 1), (6, 2), (6, 3), (6, 4), (6, 5), (6, 6), (6, 7), (6, 8), (6, 9), (6, 10), (6, 11), (6, 12), (6, 13), (6, 14), (6, 15), (7, 0), (7, 1), (7, 2), (7, 3), (7, 4), (7, 5), (7, 6), (7, 7), (7, 8), (7, 9), (7, 10), (7, 11), (7, 12), (7, 13), (7, 14), (7, 15)]
# [(0, 16), (0, 17), (0, 18), (0, 19), (0, 20), (0, 21), (0, 22), (0, 23), (0, 24), (0, 25), (0, 26), (0, 27), (0, 28), (0, 29), (0, 30), (0, 31), (1, 16), (1, 17), (1, 18), (1, 19), (1, 20), (1, 21), (1, 22), (1, 23), (1, 24), (1, 25), (1, 26), (1, 27), (1, 28), (1, 29), (1, 30), (1, 31)]
# [(2, 16), (2, 17), (2, 18), (2, 19), (2, 20), (2, 21), (2, 22), (2, 23), (2, 24), (2, 25), (2, 26), (2, 27), (2, 28), (2, 29), (2, 30), (2, 31), (3, 16), (3, 17), (3, 18), (3, 19), (3, 20), (3, 21), (3, 22), (3, 23), (3, 24), (3, 25), (3, 26), (3, 27), (3, 28), (3, 29), (3, 30), (3, 31)]
# [(4, 16), (4, 17), (4, 18), (4, 19), (4, 20), (4, 21), (4, 22), (4, 23), (4, 24), (4, 25), (4, 26), (4, 27), (4, 28), (4, 29), (4, 30), (4, 31), (5, 16), (5, 17), (5, 18), (5, 19), (5, 20), (5, 21), (5, 22), (5, 23), (5, 24), (5, 25), (5, 26), (5, 27), (5, 28), (5, 29), (5, 30), (5, 31)]
# [(6, 16), (6, 17), (6, 18), (6, 19), (6, 20), (6, 21), (6, 22), (6, 23), (6, 24), (6, 25), (6, 26), (6, 27), (6, 28), (6, 29), (6, 30), (6, 31), (7, 16), (7, 17), (7, 18), (7, 19), (7, 20), (7, 21), (7, 22), (7, 23), (7, 24), (7, 25), (7, 26), (7, 27), (7, 28), (7, 29), (7, 30), (7, 31)]
# [(8, 0), (8, 1), (8, 2), (8, 3), (8, 4), (8, 5), (8, 6), (8, 7), (8, 8), (8, 9), (8, 10), (8, 11), (8, 12), (8, 13), (8, 14), (8, 15), (9, 0), (9, 1), (9, 2), (9, 3), (9, 4), (9, 5), (9, 6), (9, 7), (9, 8), (9, 9), (9, 10), (9, 11), (9, 12), (9, 13), (9, 14), (9, 15)]
# [(10, 0), (10, 1), (10, 2), (10, 3), (10, 4), (10, 5), (10, 6), (10, 7), (10, 8), (10, 9), (10, 10), (10, 11), (10, 12), (10, 13), (10, 14), (10, 15), (11, 0), (11, 1), (11, 2), (11, 3), (11, 4), (11, 5), (11, 6), (11, 7), (11, 8), (11, 9), (11, 10), (11, 11), (11, 12), (11, 13), (11, 14), (11, 15)]
# [(12, 0), (12, 1), (12, 2), (12, 3), (12, 4), (12, 5), (12, 6), (12, 7), (12, 8), (12, 9), (12, 10), (12, 11), (12, 12), (12, 13), (12, 14), (12, 15), (13, 0), (13, 1), (13, 2), (13, 3), (13, 4), (13, 5), (13, 6), (13, 7), (13, 8), (13, 9), (13, 10), (13, 11), (13, 12), (13, 13), (13, 14), (13, 15)]
# [(14, 0), (14, 1), (14, 2), (14, 3), (14, 4), (14, 5), (14, 6), (14, 7), (14, 8), (14, 9), (14, 10), (14, 11), (14, 12), (14, 13), (14, 14), (14, 15), (15, 0), (15, 1), (15, 2), (15, 3), (15, 4), (15, 5), (15, 6), (15, 7), (15, 8), (15, 9), (15, 10), (15, 11), (15, 12), (15, 13), (15, 14), (15, 15)]
# [(8, 16), (8, 17), (8, 18), (8, 19), (8, 20), (8, 21), (8, 22), (8, 23), (8, 24), (8, 25), (8, 26), (8, 27), (8, 28), (8, 29), (8, 30), (8, 31), (9, 16), (9, 17), (9, 18), (9, 19), (9, 20), (9, 21), (9, 22), (9, 23), (9, 24), (9, 25), (9, 26), (9, 27), (9, 28), (9, 29), (9, 30), (9, 31)]
# [(10, 16), (10, 17), (10, 18), (10, 19), (10, 20), (10, 21), (10, 22), (10, 23), (10, 24), (10, 25), (10, 26), (10, 27), (10, 28), (10, 29), (10, 30), (10, 31), (11, 16), (11, 17), (11, 18), (11, 19), (11, 20), (11, 21), (11, 22), (11, 23), (11, 24), (11, 25), (11, 26), (11, 27), (11, 28), (11, 29), (11, 30), (11, 31)]
# [(12, 16), (12, 17), (12, 18), (12, 19), (12, 20), (12, 21), (12, 22), (12, 23), (12, 24), (12, 25), (12, 26), (12, 27), (12, 28), (12, 29), (12, 30), (12, 31), (13, 16), (13, 17), (13, 18), (13, 19), (13, 20), (13, 21), (13, 22), (13, 23), (13, 24), (13, 25), (13, 26), (13, 27), (13, 28), (13, 29), (13, 30), (13, 31)]
# [(14, 16), (14, 17), (14, 18), (14, 19), (14, 20), (14, 21), (14, 22), (14, 23), (14, 24), (14, 25), (14, 26), (14, 27), (14, 28), (14, 29), (14, 30), (14, 31), (15, 16), (15, 17), (15, 18), (15, 19), (15, 20), (15, 21), (15, 22), (15, 23), (15, 24), (15, 25), (15, 26), (15, 27), (15, 28), (15, 29), (15, 30), (15, 31)]
    
    
    permutated_weight = np.zeros((N // wmma_n, K // wmma_k, wmma_n, wmma_k), dtype="int8")
    for i in range(N // wmma_n):
        for j in range(K // wmma_k):
            for ii in range(wmma_n):
                for jj in range(wmma_k):
                    new_index_i, new_index_j = B_global_16x32_to_shared_load_16x32_layout(
                        ii, jj
                    )
                    permutated_weight[i, j, ii, jj] = weight[
                        i * wmma_n + new_index_i, j * wmma_k + new_index_j
                    ]

    return permutated_weight

def permutate_weight_fastest(weight):
    wmma_n = 16
    wmma_k = 32
    N = weight.shape[0]
    K = weight.shape[1]
    
    # Create a lookup table for the permutation
    mapping = np.zeros((wmma_n, wmma_k, 2), dtype=int)
    for ii in range(wmma_n):
        for jj in range(wmma_k):
            mapping[ii, jj] = B_global_16x32_to_shared_load_16x32_layout(ii, jj)
    
    # Reshape weight for the final format
    permutated_weight = np.zeros((N // wmma_n, K // wmma_k, wmma_n, wmma_k), dtype="int8")
    
    # Use advanced indexing for the entire operation
    i_indices = np.arange(N // wmma_n)[:, np.newaxis, np.newaxis, np.newaxis]
    j_indices = np.arange(K // wmma_k)[np.newaxis, :, np.newaxis, np.newaxis]
    
    # Create the source indices
    src_i = i_indices * wmma_n + mapping[:, :, 0]
    src_j = j_indices * wmma_k + mapping[:, :, 1]
    
    # Extract and reshape in one go
    permutated_weight = weight[src_i, src_j]
    
    return permutated_weight


def compress_int2_to_int8(int2_weight):
    int8_weight = np.zeros(
        (*int2_weight.shape[:-1], int2_weight.shape[-1] // 4), dtype=np.int8
    )
    for j in range(int2_weight.shape[-1] // 4):
        for k in range(4):
            int8_weight[:, :, :, j] |= int2_weight[:, :, :, j * 4 + k] << (k * 2)
    return int8_weight


def interleave_weight_int8(qweight, nbits=2):\
    # reinterpret the data type of qweight to int32
    # index: [ 0,  4,  8, 12,  1,  5,  9, 13,  2,  6, 10, 14,  3,  7, 11, 15]
    qweight = qweight.view(np.int32)
    new_qweight = np.zeros_like(qweight)
    bits_stride = 8
    mask = (1 << nbits) - 1  # for 4bit the val is 0x0000000f
    num_groups = 32 // bits_stride # 4
    elems_per_group = bits_stride // nbits  # 4
    for i in range(num_groups):
        for j in range(elems_per_group):
            offset = i * elems_per_group + j
            shift = (offset % num_groups) * bits_stride + (offset // num_groups) * nbits

            new_qweight |= ((qweight >> (nbits * offset)) & mask) << shift
    return new_qweight.view(np.int8)



def convert_weight_int8_to_int2(weight):
    N = weight.shape[0]
    K = weight.shape[1]

    weight = weight+2
    
    weight = weight.cpu().numpy()

    # print(weight)
    # print(torch.max(weight), torch.min(weight))

    # permutated_weight_slow = permutate_weight(weight)
    permutated_weight = permutate_weight_fastest(weight)
    # assert np.all(permutated_weight_slow == permutated_weight)
    # print("Permutation is correct")
    compressed_weight = compress_int2_to_int8(permutated_weight)
    interleaved_weight = interleave_weight_int8(compressed_weight, 2)

    ret = torch.from_numpy(interleaved_weight)

    ret = torch.reshape(ret, (N, K // 4))

    return ret


def find_multiple(n: int, k: int) -> int:
    if n % k == 0:
        return n
    return n + k - (n % k)


@dataclass
class ModelArgs:
    block_size: int = 2048
    vocab_size: int = 32000
    n_layer: int = 32
    n_head: int = 32
    dim: int = 4096
    intermediate_size: int = None
    n_local_heads: int = -1
    head_dim: int = 64
    rope_base: float = 10000
    norm_eps: float = 1e-5

    def __post_init__(self):
        if self.n_local_heads == -1:
            self.n_local_heads = self.n_head
        if self.intermediate_size is None:
            hidden_dim = 4 * self.dim
            n_hidden = int(2 * hidden_dim / 3)
            self.intermediate_size = find_multiple(n_hidden, 256)
        self.head_dim = self.dim // self.n_head

    @classmethod
    def from_name(cls, name: str):
        if name in transformer_configs:
            return cls(**transformer_configs[name])
        # fuzzy search
        config = [config for config in transformer_configs if config in str(name).upper() or config in str(name)]
        assert len(config) == 1, name
        return cls(**transformer_configs[config[0]])


@torch.inference_mode()
def convert_ts_checkpoint(
    *,
    checkpoint_dir: Path = Path("checkpoints/meta-Transformer/Transformer-2-7b-chat-hf"),
    file_name: str = "",
    model_name: Optional[str] = None,
) -> None:
    if model_name is None:
        model_name = checkpoint_dir.name

    config = ModelArgs.from_name(model_name)
    print(f"Model config {config.__dict__}")

    weight_map = {
        "decoder.embed_tokens.weight": "tok_embeddings.weight",
        "decoder.layers.{}.self_attn.q_proj.weight": "layers.{}.attention.wq.weight",
        "decoder.layers.{}.self_attn.k_proj.weight": "layers.{}.attention.wk.weight",
        "decoder.layers.{}.self_attn.v_proj.weight": "layers.{}.attention.wv.weight",
        "decoder.layers.{}.self_attn.out_proj.weight": "layers.{}.attention.wo.weight",
        "decoder.layers.{}.self_attn.inner_attn_ln.weight": "layers.{}.attention.attn_sub_norm.weight",
        'decoder.layers.{}.self_attn.rotary_emb.inv_freq': None,
        'decoder.layers.{}.ffn.fc3.weight': 'layers.{}.feed_forward.w1.weight',
        "decoder.layers.{}.ffn.fc1.weight": "layers.{}.feed_forward.w3.weight",
        "decoder.layers.{}.ffn.fc2.weight": "layers.{}.feed_forward.w2.weight",
        "decoder.layers.{}.ffn.ffn_layernorm.weight": "layers.{}.feed_forward.ffn_sub_norm.weight",
        "decoder.layers.{}.self_attn_layer_norm.weight": "layers.{}.attention_norm.weight",
        "decoder.layers.{}.final_layer_norm.weight": "layers.{}.ffn_norm.weight",
        "decoder.layer_norm.weight": "norm.weight",
        "decoder.output_projection.weight": "output.weight",
    }

    def quant_weight_int2(weight):
        s = 1.0 / weight.abs().mean().clamp_(min=1e-5)
        new_weight = (weight * s).round().clamp(-1, 1).to(torch.int8)
        # new_weight = convert_weight_int8_to_int2(new_weight)
        new_scale = (1.0 / s).to(torch.float16) # weight.abs().mean().clamp_(min=1e-5).to(torch.bfloat16)
        return new_weight, new_scale
    
    def quant_weight_fp16(weight):
        s = 1.0 / weight.abs().mean().clamp_(min=1e-5)
        new_weight = (weight * s).round().clamp(-1, 1) / s
        return new_weight
    
    def convert_q(weight, config):
        weight = rearrange(weight, '(g h l d) i -> (h g d l) i', l=2, d=config.head_dim // 2, h=config.n_local_heads)
        return weight
    
    def convert_k(weight, config):
        weight = rearrange(weight, '(h l d) i -> (h d l) i', l=2, d=config.head_dim // 2)
        return weight

    def convert_o(weight, config):
        weight = rearrange(weight, 'j (g h d) -> j (h g d)', h=config.n_local_heads, d=config.head_dim)
        return weight

    def convert_attn_ln(weight, config):
        weight = rearrange(weight, '(g h d) -> (h g d)', h=config.n_local_heads, d=config.head_dim)
        return weight
    
    def convert_embedding(weight):
        vocab_size, emb_size = weight.size()
        vocabs = [0, 1, 2, 3]
        vocabs += [int(line.split(' ')[-1])+4 for line in open('./bitnet.32k.vocab').read().strip().split('\n')]
        new_weight = torch.empty(len(vocabs), emb_size, dtype=torch.float16)
        for i in range(len(vocabs)):
            new_weight[i] = weight[vocabs[i]]
        return new_weight

    merged_result = {}
    for file in [f"{checkpoint_dir / file_name}"]:
        state_dict = torch.load(str(file), map_location="cpu", mmap=True)['model']
        merged_result.update(state_dict)

    final_result_int2 = {}
    for key, value in merged_result.items():
        print(key)
        if "layers" in key:
            abstract_key = re.sub(r'(\d+)', '{}', key, 1)
            layer_num = re.search(r'\d+', key).group(0)
            new_key = weight_map[abstract_key]
            if new_key is None:
                continue
            new_key = new_key.format(layer_num)
        else:
            new_key = weight_map[key]
        
        if 'attention.w' in new_key or 'feed_forward.w' in new_key:
            value, scale = quant_weight_int2(value)
            final_result_int2[f"{new_key}_scale"] = scale
        
        if 'attention.wq' in new_key:
            value = convert_q(value, config)
        
        if 'attention.wk' in new_key:
            value = convert_k(value, config)
        
        if 'attention.wo' in new_key:
            value = convert_o(value, config)
        
        if 'attention.attn_sub_norm' in new_key:
            value = convert_attn_ln(value, config)
        
        # if 'tok_embeddings' in new_key or 'output.weight' in new_key:
        #     value = convert_embedding(value)

        final_result_int2[new_key] = value

    zero = torch.zeros(1).half()
    for key in tuple(final_result_int2.keys()):
        if key.endswith('wq.weight'):
            q = final_result_int2[key]
            k = final_result_int2[key.replace("wq", "wk")]
            v = final_result_int2[key.replace("wq", "wv")]
            final_result_int2[key.replace("wq", "wqkv")] = torch.cat([q, k, v])
            del final_result_int2[key]
            del final_result_int2[key.replace("wq", "wk")]
            del final_result_int2[key.replace("wq", "wv")]
        elif key.endswith('wq.weight_scale'):
            q = final_result_int2[key].reshape(1)
            k = final_result_int2[key.replace("wq", "wk")].reshape(1)
            v = final_result_int2[key.replace("wq", "wv")].reshape(1)
            final_result_int2[key.replace("wq", "wqkv")] = torch.cat([q, q, q, q, k, v])
            del final_result_int2[key]
            del final_result_int2[key.replace("wq", "wk")]
            del final_result_int2[key.replace("wq", "wv")]
        elif key.endswith('w1.weight'):
            w1 = final_result_int2[key]
            w3 = final_result_int2[key.replace("w1", "w3")]
            final_result_int2[key.replace("w1", "w13")] = torch.cat([w1, w3])
            del final_result_int2[key]
            del final_result_int2[key.replace("w1", "w3")]
        elif key.endswith('w1.weight_scale'):
            w1 = final_result_int2[key].reshape(1)
            w3 = final_result_int2[key.replace("w1", "w3")].reshape(1)
            final_result_int2[key.replace("w1", "w13")] = torch.cat([w1, w3])
            del final_result_int2[key]
            del final_result_int2[key.replace("w1", "w3")]
        elif key.endswith('wo.weight_scale'):
            wo = final_result_int2[key].reshape(1)
            final_result_int2[key] = torch.cat([wo])
        elif key.endswith('w2.weight_scale'):
            w2 = final_result_int2[key].reshape(1)
            final_result_int2[key] = torch.cat([w2])

    for key in final_result_int2:
        if final_result_int2[key].dtype == torch.int8:
            print(key)
            final_result_int2[key] = convert_weight_int8_to_int2(final_result_int2[key])

    final_result_fp16 = {}
    for key, value in merged_result.items():
        print(key)
        if "layers" in key:
            abstract_key = re.sub(r'(\d+)', '{}', key, 1)
            layer_num = re.search(r'\d+', key).group(0)
            new_key = weight_map[abstract_key]
            if new_key is None:
                continue
            new_key = new_key.format(layer_num)
        else:
            new_key = weight_map[key]
        
        if 'attention.w' in new_key or 'feed_forward.w' in new_key:
            value = quant_weight_fp16(value)
        
        if 'attention.wq' in new_key:
            value = convert_q(value, config)
        
        if 'attention.wk' in new_key:
            value = convert_k(value, config)
        
        if 'attention.wo' in new_key:
            value = convert_o(value, config)
        
        if 'attention.attn_sub_norm' in new_key:
            value = convert_attn_ln(value, config)
        
        # if 'tok_embeddings' in new_key or 'output.weight' in new_key:
        #     value = convert_embedding(value)

        final_result_fp16[new_key] = value

    for key in tuple(final_result_fp16.keys()):
        if key.endswith('wq.weight'):
            q = final_result_fp16[key]
            k = final_result_fp16[key.replace("wq", "wk")]
            v = final_result_fp16[key.replace("wq", "wv")]
            final_result_fp16[key.replace("wq", "wqkv")] = torch.cat([q, k, v])
            del final_result_fp16[key]
            del final_result_fp16[key.replace("wq", "wk")]
            del final_result_fp16[key.replace("wq", "wv")]
        elif key.endswith('w1.weight'):
            w1 = final_result_fp16[key]
            w3 = final_result_fp16[key.replace("w1", "w3")]
            final_result_fp16[key.replace("w1", "w13")] = torch.cat([w1, w3])
            del final_result_fp16[key]
            del final_result_fp16[key.replace("w1", "w3")]

    print(f"Saving checkpoint to {checkpoint_dir / 'model-int2.pth'}")
    torch.save(final_result_int2, checkpoint_dir / "model-int2.pth")
    
    print(f"Saving checkpoint to {checkpoint_dir / 'model-fp16.pth'}")
    torch.save(final_result_fp16, checkpoint_dir / "model-fp16.pth")


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Convert TorchScale checkpoint.')
    parser.add_argument('--checkpoint_dir', type=Path, default=Path("checkpoints/meta-llama/llama-2-7b-chat-hf"))
    parser.add_argument('--file_name', type=str, default="checkpoint_last.pt")
    parser.add_argument('--model_name', type=str, default="3B")

    args = parser.parse_args()
    convert_ts_checkpoint(
        checkpoint_dir=args.checkpoint_dir,
        file_name=args.file_name,
        model_name=args.model_name,
    )
