import os, json
from sys import argv

file_path = argv[1]
data = open(file_path).read().strip().split('\n')

for dd in data:
    d = dd.split('\t')[-1]
    if len(d.split(',')) != 10:
        print(dd)
        print(len(d.split(',')))
        print()