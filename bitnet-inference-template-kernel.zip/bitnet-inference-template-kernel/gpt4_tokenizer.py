# Copyright (c) Facebook, Inc. and its affiliates. All rights reserved.
#
# This source code is licensed under the BSD license found in the
# LICENSE file in the root directory of this source tree.

import os

import tiktoken
import base64

def _load_tiktoken_bpe(tiktoken_bpe_file: str):
    with open(tiktoken_bpe_file, "rb") as f:
        contents = f.read()
    return {
        base64.b64decode(token): int(rank)
        for token, rank in (line.split() for line in contents.splitlines() if line)
    }

cl100k_base = tiktoken.get_encoding("cl100k_base")
SPECIAL_TOKENS = {
    "<s>": -4,
    "<pad>": -3,
    "</s>": -2,
    "<unk>": -1,
}

def offset_dictionary(dicts, offset=4):
    for k in dicts:
        dicts[k] += offset
    return dicts

class Tokenizer:
    """Encoding/decoding text using SentencePiece."""

    def __init__(self, use_full_vocab=False):
        """
        Initializes the Tokenizer with a SentencePiece model.

        Args:
            model_path (str): The path to the SentencePiece model file.
        """
        if use_full_vocab:
            self.tokenizer = tiktoken.Encoding(
                # If you're changing the set of special tokens, make sure to use a different name
                # It should be clear from the name what behaviour to expect.
                name="cl100k_im",
                pat_str=cl100k_base._pat_str,
                mergeable_ranks=offset_dictionary(cl100k_base._mergeable_ranks),
                special_tokens=offset_dictionary({
                    **cl100k_base._special_tokens,
                    "<fim_prefix>": 100264,
                    "<fim_middle>": 100265,
                    "<fim_suffix>": 100266,
                    "<fim_pad>": 100267,
                    "<reponame>": 100268,
                    "<filename>": 100269,
                    "<gh_stars>": 100270,
                    "<issue_start>": 100271,
                    "<issue_comment>": 100272,
                    "<issue_closed>": 100273,
                    "<jupyter_start>": 100274,
                    "<jupyter_text>": 100275,
                    "<jupyter_code>": 100276,
                    "<jupyter_output>": 100277,
                    "<empty_output>": 100278,
                    "<commit_before>": 100279,
                    "<commit_msg>": 100280,
                    "<commit_after>": 100281,
                    "<s>": -4,
                    "<pad>": -3,
                    "</s>": -2,
                    "<unk>": -1,
                })
            )
            self.n_words = 100287
        else:
            mergeable_ranks = _load_tiktoken_bpe('./bitnet32k.tiktoken')
            self.tokenizer = tiktoken.Encoding(
                # If you're changing the set of special tokens, make sure to use a different name
                # It should be clear from the name what behaviour to expect.
                name="cl100k_im",
                pat_str=cl100k_base._pat_str,
                mergeable_ranks=offset_dictionary(mergeable_ranks),
                special_tokens=offset_dictionary(SPECIAL_TOKENS),
            )
            self.n_words = 32321
        self.bos_id = 0
        self.eos_id = 2
        self.pad_id = 1
        print(
            f"loaded SentencePiece model: "
            f"#words: {self.n_words} - "
            f"bos id: {self.bos_id} - "
            f"eos id: {self.eos_id}"
        )
        # assert self.sp_model.vocab_size() == self.sp_model.get_piece_size()

    def encode(self, s: str, bos: bool = True, eos: bool = False) -> list[int]:
        """
        Encodes a string into a list of token IDs.

        Args:
            s (str): The input string to be encoded.
            bos (bool): Whether to prepend the beginning-of-sequence token.
            eos (bool): Whether to append the end-of-sequence token.

        Returns:
            list[int]: A list of token IDs.
        """
        assert type(s) is str
        t = self.tokenizer.encode(s, allowed_special="all")
        # t = [i + 4 for i in t]
        if bos:
            t = [self.bos_id] + t
        if eos:
            t = t + [self.eos_id]
        return t

    def decode(self, t: list[int]) -> str:
        """
        Decodes a list of token IDs into a string.

        Args:
            t (list[int]): The list of token IDs to be decoded.

        Returns:
            str: The decoded string.
        """
        t = [i for i in t if i >= 4]
        return self.tokenizer.decode(t)
